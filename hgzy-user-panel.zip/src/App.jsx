import React from "react";
import LiveScoreBoard from "./components/LiveScoreBoard";

function App() {
  return (
    <div className="App">
      <LiveScoreBoard />
    </div>
  );
}

export default App;
